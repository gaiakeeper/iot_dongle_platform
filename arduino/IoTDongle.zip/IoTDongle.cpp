#include <Arduino.h>

#include "IoTDongle.h"

using namespace IoTD;

// 4 bits resource from 0 to 15
#define IOTD_SHORT_RESOURCE_MAX		16
// 7 bits value from 0 to 127
#define IOTD_SHORT_VALUE_MAX		128
// 6 bits value from 0 to 63
#define IOTD_SHORT_LENGTH_MAX		64

union Message {
	struct {
		unsigned char _res:4;		// 
		unsigned char _rex:1;		// resource extended or not
		unsigned char _api:2;		// C.R.U.D
		unsigned char _cmd:1;		// call or cmdurn
		unsigned char _res2;
	};
	unsigned char _data[2];

	Message(unsigned char d0=0, unsigned char d1=0){ set(d0, d1); };
	Message(Command cmd, Method api, Resource res){ set(cmd, api, res); };

	void set(unsigned char d0=0, unsigned char d1=0);
	void set(Command cmd, Method api, Resource res);

	Command		getCommand() const { return (Command)_cmd; };
	Method		getMethod() const { return (Method)_api; };
	Resource	getResource() const;
};

void Message::set(unsigned char d0, unsigned char d1)
{
	_data[0] = d0;
	_data[1] = d1;
}

void Message::set(Command cmd, Method api, Resource res)
{
	if(res < IOTD_SHORT_RESOURCE_MAX){
		_cmd = cmd;
		_api = api;
		_rex = 0;
		_res = (unsigned char)res;
	}
	else {
		_data[1] = (unsigned char)res;
		_data[0] = (unsigned char)(res>>8);
		/*
		_data[0] = ((unsigned char*)(&res))[1];				// little-endian
		_data[1] = ((unsigned char*)(&res))[0];				// little-endian
		*/

		_cmd = cmd;
		_api = api;
		_rex = 1;
	}
}

Resource Message::getResource() const
{
	Resource res = _res;
	if ( _rex ){
		res <<= 8;
		res += _res2;
	}
	return res;
}


Device::Device(Resource max)
{
	_sizeOfCallbackList = 2 * 4 * max;
	_callbackList = new Callback[_sizeOfCallbackList];
	for(int i=0; i<_sizeOfCallbackList; i++)
		_callbackList[i] = NULL;
}

Device::~Device()
{
	delete[] _callbackList;
}


void Device::begin()
{
	Serial.begin(9600);
}

void Device::end()
{
}

void Device::loop()
{
	Command cmd;
	Method api;
	Resource res;

	unsigned int index;
	while(Serial.available()){
		receiveCommand(cmd, api, res);
		index = res * 8 + cmd * 4 + api;
		if ( _callbackList[index] ) _callbackList[index](cmd, api, res);
	}
}

void Device::setCallback(Command cmd, Method api, Resource res, void (*callback)(Command cmd, Method api, Resource res))
{
	unsigned int index = res * 8 + cmd * 4 + api;
	_callbackList[index] = callback;
}

void Device::sendCommand(Command cmd, Method api, Resource res)
{
	Message msg(cmd, api, res);

	Serial.write(msg._data[0]);
	if(msg._rex) Serial.write(msg._data[1]);
}

void Device::receiveCommand(Command &com, Method &api, Resource &res)
{
	while(Serial.available()==0) ; // wait for read
	Message msg((unsigned char)Serial.read());
	if(msg._rex){
		while(Serial.available()==0) ; // wait for read
		msg._data[1] = (unsigned char)Serial.read();
	}
	com = msg.getCommand();
	api = msg.getMethod();
	res = msg.getResource();
}

void Device::sendData(unsigned char value)
{
	if ( value < IOTD_SHORT_VALUE_MAX ){
		Serial.write((unsigned char)value);
	}
	else {
		Serial.write(0x81);
		Serial.write(value);
	}
}

void Device::sendData(unsigned short length, const unsigned char* data)
{
	if ( length < IOTD_SHORT_LENGTH_MAX ){
		unsigned char data = (unsigned char)(length);
		data |= 0x80;				// 1st bit = 1
		Serial.write(data);
	}
	else {
		unsigned char data = (unsigned char)(length>>8);
		data |= 0xc0;				// 1st & 2nd bit = 1
		Serial.write(data);
		Serial.write((unsigned char)length);
	}

	for(unsigned short i=0; i<length; i++)
		Serial.write(data[i]);
}

void Device::receiveData(unsigned char &value)
{
	while(Serial.available()==0) ; // wait for read
	value = Serial.read();
}

void Device::receiveData(unsigned short &length, unsigned char* data)
{
	while(Serial.available()==0) ; // wait for read
	unsigned char len = Serial.read();
	if ( len & 0x80 ){
		length = len & 0x3F;
		if ( len & 0x40 ){
			while(Serial.available()==0) ; // wait for read
			length <<= 8;
			length += Serial.read();
		}

		while(Serial.available()<length) ; // wait for read
		Serial.readBytes(data, length);
	}
	else {		// one byte data
		length = 1;
		*data = len;
	}
}