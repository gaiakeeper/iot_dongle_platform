#pragma once

namespace IoTD
{
	enum Command {
		COMMAND_CALL		= 0,
		COMMAND_RETURN		= 1,
	};
	enum Method {
		METHOD_CREATE		= 0,
		METHOD_READ			= 1,
		METHOD_UPDATE		= 2,
		METHOD_DELETE		= 3,
		METHOD_GET			= METHOD_READ,
		METHOD_SET			= METHOD_UPDATE,
		METHOD_ADD			= METHOD_CREATE,
		METHOD_REMOVE		= METHOD_DELETE,
	};
	typedef unsigned short Resource;

	enum Error {
		ERROR_NONE			= 0,
	};

	class Device {
	private:
		typedef void (*Callback)(Command cmd, Method api, Resource res);
		unsigned int _sizeOfCallbackList;
		Callback *_callbackList;

	protected:
		Device(Resource max);

	public:
		virtual ~Device();

	public:
		void begin();
		void end();
		void loop();

	public:
		void setCallback(Command cmd, Method api, Resource res, Callback func);

	public:
		static void sendCommand(Command cmd, Method api, Resource res);
		static void sendData(unsigned char value);
		static void sendData(unsigned short length, const unsigned char* data);
		static void receiveCommand(Command &cmd, Method &api, Resource &res);
		static void receiveData(unsigned char &value);
		static void receiveData(unsigned short &length, unsigned char* data);
	};

	class AirConditioner : public Device {
	public:
		AirConditioner() : Device(RESOURCE_MAX){};
		virtual ~AirConditioner(){};

	public:
		enum {
			RESOURCE_LOG			= 0,
			RESOURCE_TYPE			= 1,
			RESOURCE_POWER			= 2,
			RESOURCE_TEMPERATURE	= 3,
			RESOURCE_PREFERRED		= 4,
			RESOURCE_MAX			= 5,
		};
	};
	
	class Humidifier : public Device {
	public:
		Humidifier() : Device(RESOURCE_MAX){};
		virtual ~Humidifier(){};

	public:
		enum {
			RESOURCE_LOG			= 0,
			RESOURCE_TYPE			= 1,
			RESOURCE_POWER			= 2,
			RESOURCE_HUMIDITY	= 3,
			RESOURCE_PREFERRED		= 4,
			RESOURCE_MAX			= 5,
		};
	};

	class Plug : public Device {
	public:
		Plug() : Device(RESOURCE_MAX){};
		virtual ~Plug(){};

	public:
		enum {
			RESOURCE_LOG			= 0,
			RESOURCE_TYPE			= 1,
			RESOURCE_POWER			= 2,
			RESOURCE_NUMBER			= 3,
			RESOURCE_POWER1			= 4,
			RESOURCE_POWER2			= 5,
			RESOURCE_POWER3			= 6,
			RESOURCE_POWER4			= 7,
			RESOURCE_POWER5			= 8,
			RESOURCE_POWER6			= 9,
			RESOURCE_POWER7			= 10,
			RESOURCE_POWER8			= 11,
			RESOURCE_POWER9			= 12,
			RESOURCE_MAX			= 13,
		};
	};
};
